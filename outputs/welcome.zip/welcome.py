def hello(event, context):
    print("Welcome to terraform - Arunreddy ")